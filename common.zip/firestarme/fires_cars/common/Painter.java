package firestarme.fires_cars.common;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.World;

public class Painter{ 
	
	static int texture;
	ItemStack Itemstack;
	Item item;
	static boolean itemUsed = false;
	static boolean blockUsed = false;
	static EntityPlayer playerb;
	static EntityPlayer playeri;

}