package firestarme.fires_cars.common;
public class fires_carsCommonProxy {

	public static String Block_png = ("/firestarme/fires_cars/block.png");
	public static String Item_png = ("/firestarme/fires_cars/items.png");
	
	public void registerRenderers()
	{
		//server side, no renderer
		
	}
}
